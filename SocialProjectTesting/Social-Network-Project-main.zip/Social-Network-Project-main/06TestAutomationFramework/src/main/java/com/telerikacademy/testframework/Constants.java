package com.telerikacademy.testframework;

public class Constants {
    public static String editedComment;
    public static String personalInfo;
    public static String homePageHeader = "The Easiest Way to Hack the Crisis";
    public static String logoutPageHeader = "Login Page";
    public static String skillInfo = "Quality Assurance";
    public static String jobTitle = "Translator";

}
