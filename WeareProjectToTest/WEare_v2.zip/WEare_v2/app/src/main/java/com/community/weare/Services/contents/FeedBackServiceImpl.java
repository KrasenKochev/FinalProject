package com.community.weare.Services.contents;

import com.community.weare.Models.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;

public class FeedBackServiceImpl implements FeedBackService {
}
