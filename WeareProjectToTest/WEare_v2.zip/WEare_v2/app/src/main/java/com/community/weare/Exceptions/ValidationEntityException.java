package com.community.weare.Exceptions;

public class ValidationEntityException extends RuntimeException {

    public ValidationEntityException(String message) {
        super((message));
    }

}
